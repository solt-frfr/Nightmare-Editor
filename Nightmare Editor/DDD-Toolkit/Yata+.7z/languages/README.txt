YATA+ now support multiple languages, to translate YATA+ copy the Eng_template
folder and rename it with the name of the lang you are going to make, then replace
the strings in the txt files, make sure to save the file in the UTF-8 format, or else
some characters like � or � won't be visible in YATA+.
You can also delete the languages folder, YATA+ includes the inglish as primary language and works even without that folder.
You should start translating from main.txt, that explains how object names works and how to create new lines etc..
Things like windows' titles and some error messages can't be translated.

imgSIZES.txt doesn't follow the same rules as the other files, here you must write directly what you want to be viewed in YATA+

FOR TRANSLATORS: v1.8 doesn't include changes, you just need to change the version inside main.txt from 1.7 to 1.8

FOR TRANSLATORS: v1.7 update includes these changes:
	install.txt was remade from scratch, based on installTOchmm.txt
	Inside CONVERTsettings.txt:
		btn_WAVbcstm=Convert from WAV to BCSTM
	Inside main.txt:
		ver=1.7
		edit_tools=Tools
		tools_comp=LZ compress
		tools_dec=LZ decompress
		install_WithThemeInst=Send the theme via FTP on a 3DS
	at the BOTTOM OF THE FILE:
		@Done !

FOR TRANSLATORS: v1.6.1 update includes these new strings:
	Inside prefs.txt:
		New string:
		lbl_optSample=When optimizing set the sample rate to:
		at the BOTTOM OF THE FILE:
		@Using a sample rate not included in the list may corrupt the sound
	Inside main.txt:
		ver=1.6.1


FOR TRANSLATORS: v1.6 update includes these new strings:
	Added installTOchmm.txt
	Inside CwavsDumper.txt:
		btn_play=Play was removed		
	Inside main.txt:
	      at the top now there is a version number for the lang, it is the same as the yata version and it MUST BE AT THE TOP:
		ver=1.6
	      new strings:
		install_WithThemeInst=Install with YATA+ theme installer
		install_WithCHMM2=Install with CHMM2 (only ninjhax 1)
		lbl_playerDisabled=Player disabled in the settings
	      at the BOTTOM OF THE FILE:
		@Some cwavs weren't converted
		@This theme has the 'Use BMG' flag checked in the settings, but in its path there's not a bgm.bcstm file, if you try to install this theme without a bgm, or you don't disable it in the theme settings the home menu will crash
		@bgm.bcstm was not found, the bgm will be disabled
	Inside prefs.txt:
		chb_extplayer=Use an external audio player
		"@Restart YATA to fully change the language" was changed to: "@You may need YATA+ to fully apply the settings"
		

FOR TRANSLATORS: v1.5 update includes only one new string to translate in sett.txt:
		btn_prev=preview